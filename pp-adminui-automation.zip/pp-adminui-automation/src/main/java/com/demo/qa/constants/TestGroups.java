package com.demo.qa.constants;

public interface TestGroups {
	String RELEASE = "Release";
	String SMOKE = "Smoke";
	String E2E = "End to End";
	String INTEGRATION = "Integration Test";
	String REGRESSION = "Regression Test";
}
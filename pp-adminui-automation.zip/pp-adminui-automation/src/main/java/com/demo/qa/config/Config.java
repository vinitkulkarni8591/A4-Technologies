package com.demo.qa.config;

import static java.lang.String.format;
import static java.lang.System.getProperty;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringSubstitutor.replaceSystemProperties;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Config {
	private static final Properties app;
	private static final Logger log;
	private static final Properties main;

	static {
		final String environment = getProperty ("env", "dev");
		log = LogManager.getLogger (Config.class);
		app = new Properties ();
		main = new Properties ();
		loadProperty (format ("config-qa.properties", environment), app);
		loadProperty ("main-config.properties", main);
	}

	public static String getAppConfig (final String key) {
		return getAppConfig (key, EMPTY);
	}

	public static String getAppConfig (final String key, final String defaultValue) {
		return replaceSystemPropertyIfAny (app.getProperty (key, defaultValue));
	}

	public static String getConfig (final String key) {
		return getConfig (key, EMPTY);
	}

	public static String getConfig (final String key, final String defaultValue) {
		return replaceSystemPropertyIfAny (main.getProperty (key, defaultValue));
	}

	private static void loadProperty (final String file, final Properties prop) {
		try (
			InputStream in = Config.class.getClassLoader ()
				.getResourceAsStream (file)) {
			if (in == null) throw new FileNotFoundException ("Config File not found.");
			prop.load (in);
		}
		catch (final IOException e) {
			log.error ("Unable to load config file! " + e.getLocalizedMessage (), e);
		}
	}

	private static String replaceSystemPropertyIfAny (final String value) {
		return value.contains ("${") ? replaceSystemProperties (value) : value;
	}
}
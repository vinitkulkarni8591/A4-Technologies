package com.demo.qa.selenium;

import static com.demo.qa.config.Config.getConfig;
import static com.demo.qa.constants.ConfigKeys.EXPLICIT_DELAY;
import static com.demo.qa.constants.ConfigKeys.PAUSE_TIME;
import static com.google.common.truth.Truth.assertThat;
import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;
import static java.lang.Thread.sleep;

import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.truth.StringSubject;

import io.qameta.allure.Attachment;
import io.qameta.allure.Step;

public class BrowserActions {
	private final EventFiringWebDriver driver;
	private final WebDriverWait wait;
	private static final Logger log = LogManager.getLogger (BrowserActions.class);

	public BrowserActions (final EventFiringWebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait (driver, parseInt (getConfig (EXPLICIT_DELAY, "10")));
	}

	@Step ("Accepting Alert pop-up.")
	public String acceptAlert () {
		final Alert alert = this.wait.until (ExpectedConditions.alertIsPresent ());
		String message = null;
		if (alert != null) {
			message = alert.getText ();
			alert.accept ();
		}
		return message;
	}

	@Attachment
	public String attachMessage (final String message) {
		return message;
	}

	@Step ("Deleting all cookies.")
	public void deleteCookies () {
		perform (d -> d.manage ()
			.deleteAllCookies ());
	}

	@Step ("Dismissing Alert pop-up.")
	public String dismissAlert () {
		final Alert alert = this.wait.until (ExpectedConditions.alertIsPresent ());
		String message = null;
		if (alert != null) {
			message = alert.getText ();
			alert.dismiss ();
		}
		return message;
	}

	public WebDriverWait driverWait () {
		return this.wait;
	}

	public boolean isClosed () {
		return get (d -> ((RemoteWebDriver) d.getWrappedDriver ()).getSessionId () == null);
	}

	@Step ("Navigating to URL [{url}].")
	public void navigateTo (final String url) {
		perform (d -> d.navigate ()
			.to (url));
	}

	@Attachment
	public byte [] saveScreenshot () {
		return get (d -> ((TakesScreenshot) d).getScreenshotAs (OutputType.BYTES));
	}

	@Step ("Switching to main window.")
	public void switchToMain () {
		perform (d -> d.switchTo ()
			.defaultContent ());
	}

	@Step ("Switching to window [{title}].")
	public void switchToWindow (final String title) {
		perform (d -> {
			final Set <String> wins = d.getWindowHandles ();
			for (final String win : wins) {
				final WebDriver w = d.switchTo ()
					.window (win);
				if (w.getTitle ()
					.contains (title)) {
					return;
				}
			}
		});
	}

	public String title () {
		return get (WebDriver::getTitle);
	}

	@Step ("Verifying Alert message after accepting it.")
	public StringSubject verifyAcceptedAlert () {
		return assertThat (acceptAlert ());
	}

	@Step ("Verifying Alert message after dismissing it.")
	public StringSubject verifyDismissedAlert () {
		return assertThat (dismissAlert ());
	}

	@Step ("Verifying Browser Title.")
	public StringSubject verifyTitle () {
		return assertThat (title ());
	}

	EventFiringWebDriver driver () {
		return this.driver;
	}

	private <E> E get (final Function <EventFiringWebDriver, E> func) {
		return func.apply (this.driver);
	}

	private void perform (final Consumer <EventFiringWebDriver> action) {
		action.accept (this.driver);
	}

	public void pause () {
		try {
			final long delay = parseLong (getConfig (PAUSE_TIME, "5000"));
			sleep (delay);
		}
		catch (final InterruptedException e) {
			log.catching (e);
			log.error ("FAILED to pause on driver...");
			Thread.currentThread ()
				.interrupt ();
		}
	}

	public String currentPageUrl () {
		return get (WebDriver::getCurrentUrl);
	}

	public void waitForLoad () {
		final ExpectedCondition <Boolean> pageLoadCondition = driver -> ((JavascriptExecutor) driver)
			.executeScript ("return document.readyState")
			.equals ("complete");
		final WebDriverWait wait = new WebDriverWait (this.driver, 30);
		wait.until (pageLoadCondition);
	}

	@Step ("Refresh the WebPage")
	public void refresh () {
		perform (d -> d.navigate ()
			.refresh ());
	}

	@Step ("Navigate Back")
	public void back () {
		perform (d -> d.navigate ()
			.back ());
	}

}
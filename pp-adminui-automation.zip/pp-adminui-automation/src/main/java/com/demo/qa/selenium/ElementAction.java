package com.demo.qa.selenium;

import static com.demo.qa.config.Config.getConfig;
import static com.demo.qa.constants.ConfigKeys.HIGHLIGHT_DELAY;
import static com.demo.qa.constants.ConfigKeys.HOVER_DELAY;
import static com.google.common.truth.Truth.assertThat;
import static java.lang.Thread.sleep;
import static java.text.MessageFormat.format;
import static java.time.Duration.ofMillis;
import static org.openqa.selenium.support.ui.ExpectedConditions.attributeToBe;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOf;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.truth.BooleanSubject;
import com.google.common.truth.StringSubject;

import io.qameta.allure.Step;

public class ElementAction {
	private static final Logger log = LogManager.getLogger (ElementAction.class);

	private final Actions actions;
	private boolean alreadyHighlighted;
	private final BrowserActions browserAction;
	private By by;
	private final EventFiringWebDriver driver;
	private WebElement element;
	private String style;
	private boolean useBy;
	private final WebDriverWait wait;

	private ElementAction (final BrowserActions browserAction) {
		this.browserAction = browserAction;
		this.driver = browserAction.driver ();
		this.actions = new Actions (this.driver);
		this.wait = browserAction.driverWait ();
		this.alreadyHighlighted = false;
	}

	public ElementAction (final BrowserActions browserAction, final By by) {
		this (browserAction);
		this.by = by;
		this.useBy = true;
	}

	public ElementAction (final BrowserActions browserAction, final WebElement element) {
		this (browserAction);
		this.element = element;
		this.useBy = false;
	}

	public String attribute (final String name) {
		return get (e -> e.getAttribute (name));
	}

	@Step ("Clearing element.")
	public void clear () {
		perform (WebElement::clear);
	}

	@Step ("Clicking on element.")
	public void click () {
		perform (WebElement::click);
	}

	@Step ("Entering text [{text}] in element.")
	public void enterText (final String text) {
		perform (e -> {
			if (!StringUtils.isEmpty (text)) {
				e.sendKeys (text);
			}
		});
	}

	public ElementAction find (final By byLocator) {
		return get (e -> new ElementAction (this.browserAction, e.findElement (byLocator)));
	}

	public List <ElementAction> finds (final By byLocator) {
		return get (e -> e.findElements (byLocator)).stream ()
			.map (e -> new ElementAction (this.browserAction, e))
			.collect (Collectors.toList ());
	}

	private <T> T get (final Function <WebElement, T> func) {
		return get (func, true);
	}

	private <T> T get (final Function <WebElement, T> func, final boolean toWait) {
		prepareForAction ("green", toWait);
		return func.apply (this.element);
	}

	private void highlight (final String color) {
		if (!this.alreadyHighlighted) {
			this.style = this.element.getAttribute ("style");
			final JavascriptExecutor exec = this.driver;
			exec.executeScript ("arguments[0].setAttribute('style', arguments[1] + arguments[2]);", this.element,
				this.style, format ("color: {0}; border: 3px solid {0};", color));
		}
	}

	@Step ("Hovering on element.")
	public void hover () {
		perform (e -> {
			waitUntilVisible ();
			final long delay = Long.parseLong (getConfig (HOVER_DELAY, "500"));
			this.actions.moveToElement (e)
				.pause (ofMillis (delay))
				.perform ();
		});
	}

	public boolean isDisplayed () {
		return get (WebElement::isDisplayed, false);
	}

	public boolean isEnabled () {
		return get (WebElement::isEnabled);
	}

	public boolean isSelected () {
		return get (WebElement::isSelected);
	}

	public void pause () {
		try {
			final long delay = Long.parseLong (getConfig (HIGHLIGHT_DELAY));
			sleep (delay);
		}
		catch (final InterruptedException e) {
			log.catching (e);
			log.error ("FAILED while pausing on element...");
			Thread.currentThread ()
				.interrupt ();
		}
	}

	private void perform (final Consumer <WebElement> action) {
		prepareForAction ("red", true);
		action.accept (this.element);
	}

	private void prepareForAction (final String color, final boolean toWait) {
		if (toWait) {
			waitUntilVisible ();
			scrollIntoView ();
			highlight (color);
			pause ();
			unhighlight ();
		}
	}

	@Step ("Pressing keys [{keys}] in element.")
	public void pressKey (final Keys... keys) {
		perform (e -> e.sendKeys (keys));
	}

	private void scrollIntoView () {
		final String script = "var viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);\n"
			+ "var elementTop = arguments[0].getBoundingClientRect().top;\n"
			+ "window.scrollBy(0, elementTop-(viewPortHeight/2));";
		final JavascriptExecutor js = this.driver;
		js.executeScript (script, this.element);
	}

	@Step ("Selecting value [{value}] from element.")
	public void select (final String value) {

		perform (e -> {
			click ();
			final List <WebElement> options = e.findElements (By.xpath ("//mat-option/span"));
			final Optional <ElementAction> option = options.stream ()
				.map (o -> new ElementAction (this.browserAction, o))
				.filter (s -> s.text ()
					.trim ()
					.equals (value))
				.findFirst ();
			if (option.isPresent ()) {
				option.get ()
					.click ();
			}
		});
	}

	public String text () {
		return get (WebElement::getText);
	}

	private void unhighlight () {
		if (!this.alreadyHighlighted) {
			final JavascriptExecutor exec = this.driver;
			exec.executeScript ("arguments[0].setAttribute('style', arguments[1]);", this.element, this.style);
			this.alreadyHighlighted = true;
		}
	}

	@Step ("Verifying attribute [{attribute}] of an element.")
	public StringSubject verifyAttribute (final String attribute) {
		return assertThat (attribute (attribute));
	}

	@Step ("Verifying if element is displayed.")
	public BooleanSubject verifyDisplayed () {
		return assertThat (isDisplayed ()).named ("Is Displayed?");
	}

	@Step ("Verifying if element is enabled.")
	public BooleanSubject verifyEnabled () {
		return assertThat (isEnabled ()).named ("Is Enabled?");
	}

	@Step ("Verifying if element is selected.")
	public BooleanSubject verifySelected () {
		return assertThat (isSelected ()).named ("Is Selected?");
	}

	@Step ("Verifying element text.")
	public StringSubject verifyText () {
		return assertThat (text ());
	}

	@Step ("Verifying text in array")
	public void verifyTextInArray (String [] stringArray) {
		assertThat (text ()).isIn (Arrays.asList (stringArray));
	}

	public void waitUntilAttributeIs (final String attribute, final String value) {
		if (this.useBy) {
			waitUntilLocatorAttributeIs (attribute, value);
		}
		else {
			this.wait.until (attributeToBe (this.element, attribute, value));
		}
	}

	public void waitUntilClickable () {
		if (this.useBy) {
			waitUntilLocatorClickable ();
		}
		else {
			this.wait.until (elementToBeClickable (this.element));
		}
	}

	public void waitUntilInvisible () {
		if (this.useBy) {
			waitUntilLocatorInvisible ();
		}
		else {
			this.wait.until (invisibilityOf (this.element));
		}
	}

	private void waitUntilLocatorAttributeIs (final String attribute, final String value) {
		this.wait.until (attributeToBe (this.by, attribute, value));
	}

	private void waitUntilLocatorClickable () {
		this.element = this.wait.until (elementToBeClickable (this.by));
	}

	private void waitUntilLocatorInvisible () {
		this.wait.until (invisibilityOfElementLocated (this.by));
	}

	private void waitUntilLocatorVisible () {
		this.element = this.wait.until (visibilityOfElementLocated (this.by));
	}

	public void waitUntilVisible () {
		if (this.useBy) {
			waitUntilLocatorVisible ();
		}
		else {
			this.wait.until (visibilityOf (this.element));
		}
	}

	@Step ("Verifying tooltip text.")
	public void verifyToolTipText (final By byLocator, String text) {
		perform (e -> {
			this.actions.moveToElement (e)
				.build ()
				.perform ();
		});
		find (byLocator).verifyText ()
			.isEqualTo (text);
	}

	@Step ("Verify the String is present from array of Strings.")
	public void containsWords (ElementAction action, String [] items) {
		for (final String item : items) {
			action.verifyText ()
				.contains (item);
		}
	}

	@Step ("Selecting value from dropdown option.")
	public void selectFromDropDown (List <ElementAction> actionList, final String value) {
		for (final ElementAction action : actionList) {
			final String monthValue = action.attribute ("value");
			if (monthValue.equals (value)) {
				action.click ();
				break;
			}
		}
	}

	@Step ("Hovering and Clicking on element.")
	public void hoverAndClick () {
		perform (e -> {
			waitUntilVisible ();
			final long delay = Long.parseLong (getConfig (HOVER_DELAY, "500"));
			this.actions.moveToElement (e)
				.pause (ofMillis (delay))
				.click ()
				.perform ();
		});
	}

	public String cssValue (String value) {
		return this.element.getCssValue (value);
	}

	@Step ("Selecting value [{value}] from element.")
	public void selectMat (final String value) {
		perform (e -> {
			click ();
			final List <WebElement> options = e.findElements (By.xpath ("//mat-option/span"));
			final Optional <ElementAction> option = options.stream ()
				.map (o -> new ElementAction (this.browserAction, o))
				.filter (s -> s.text ()
					.trim ()
					.equals (value))
				.findFirst ();
			if (option.isPresent ()) {
				option.get ()
					.click ();
			}
		});
	}
}
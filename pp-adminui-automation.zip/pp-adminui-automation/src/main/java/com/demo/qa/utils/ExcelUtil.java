package com.demo.qa.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {
	static Workbook workbook = null;
	static Sheet spreadsheet = null;
	static FileInputStream inputStream = null;
	private static final Logger log = LogManager.getLogger (ExcelUtil.class);

	private static void openWorkBook (String filePath) throws IOException {
		if (workbook == null) {
			File file = new File (filePath);
			inputStream = new FileInputStream (file);
			String fileExtensionName = filePath.substring (filePath.indexOf ("."));
			if (fileExtensionName.equals (".xlsx")) {
				workbook = new XSSFWorkbook (inputStream);
				log.info ("XSSF workbook instance created");
			}
			else {
				workbook = new HSSFWorkbook (inputStream);
				log.info ("HSSF workbook instance created");
			}
		}
	}

	private static void getExcelSheet (String sheetName) {
		if (workbook.getNumberOfSheets () != 0) {
			for (int i = 0; i < workbook.getNumberOfSheets (); i++) {
				if (workbook.getSheetName (i)
					.equals (sheetName)) {
					spreadsheet = workbook.getSheet (sheetName);
					log.info ("Found " + sheetName + " sheet");
				}
			}
		}
	}

	public static List <Object []> getTestData (String filePath, String sheetName, String startValue, int totalCases)
		throws IOException {
		openWorkBook (filePath);
		getExcelSheet (sheetName);
		List <Object []> data = new ArrayList <> ();
		int row = 0;
		for (int i = 0; i < spreadsheet.getLastRowNum (); i++) {
			if (spreadsheet.getRow (i)
				.getCell (0)
				.getStringCellValue ()
				.equals (startValue)) {
				row = i + 1;
				break;
			}
		}
		int conditionRow = row + totalCases;
		while (row < conditionRow) {
			Row sheetRow = spreadsheet.getRow (row);
			Object [] testData = new Object [sheetRow.getLastCellNum ()];
			Cell cell = null;
			for (int j = 0; j < sheetRow.getLastCellNum (); j++) {
				cell = sheetRow.getCell (j);
				switch (cell.getCellType ()) {
				case STRING:
					testData [j] = cell.getStringCellValue ();
					break;
				case BOOLEAN:
					testData [j] = cell.getBooleanCellValue ();
					break;
				default:
					testData [j] = new DataFormatter ().formatCellValue (cell);
					break;
				}
			}
			data.add (new Object [] { Arrays.toString (testData) });
			row++;
		}
		return data;
	}
}

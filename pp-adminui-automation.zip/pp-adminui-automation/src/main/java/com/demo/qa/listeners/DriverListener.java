package com.demo.qa.listeners;

import static java.lang.String.format;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class DriverListener implements WebDriverEventListener {
	private static final Logger log = LogManager.getLogger (DriverListener.class);

	@Override
	public void afterAlertAccept (final WebDriver driver) {
		log.trace ("Alert dialog accepted...");
	}

	@Override
	public void afterAlertDismiss (final WebDriver driver) {
		log.trace ("Alert dialog dismissed...");
	}

	@Override
	public void afterChangeValueOf (final WebElement element, final WebDriver driver,
		final CharSequence [] keysToSend) {
		if (keysToSend != null) {
			final String message = "Text [%s] has been entered...";
			log.trace (format (message, (Object []) keysToSend));
		}
	}

	@Override
	public void afterClickOn (final WebElement element, final WebDriver driver) {
		log.trace ("Clicked on element...");
	}

	@Override
	public void afterFindBy (final By by, final WebElement element, final WebDriver driver) {
		log.trace (format ("Element found using [%s]...", by));
	}

	@Override
	public <X> void afterGetScreenshotAs (final OutputType <X> target, final X screenshot) {
		log.trace (format ("Screenshot captured in [%s] format...", target));
	}

	@Override
	public void afterGetText (final WebElement element, final WebDriver driver, final String text) {
		log.trace (format ("Text [%s] retreived from element found...", text));
	}

	@Override
	public void afterNavigateBack (final WebDriver driver) {
		log.trace ("Navigated backward...");
	}

	@Override
	public void afterNavigateForward (final WebDriver driver) {
		log.trace ("Navigated forward...");
	}

	@Override
	public void afterNavigateRefresh (final WebDriver driver) {
		log.trace ("Page refreshed...");
	}

	@Override
	public void afterNavigateTo (final String url, final WebDriver driver) {
		log.trace (format ("Navigated to url [%s]...", url));
	}

	@Override
	public void afterScript (final String script, final WebDriver driver) {
		log.trace (format ("Script [%s] executed successfully...", script));
	}

	@Override
	public void afterSwitchToWindow (final String windowName, final WebDriver driver) {
		log.trace (format ("Window switched to [%s]...", windowName));
	}

	@Override
	public void beforeAlertAccept (final WebDriver driver) {
		log.info ("Accepting Alert pop-up...");
	}

	@Override
	public void beforeAlertDismiss (final WebDriver driver) {
		log.info ("Dismissing Alert pop-up...");
	}

	@Override
	public void beforeChangeValueOf (final WebElement element, final WebDriver driver,
		final CharSequence [] keysToSend) {
		if (keysToSend != null) {
			log.info (format ("Writing text [%s]...", (Object []) keysToSend));
		}
	}

	@Override
	public void beforeClickOn (final WebElement element, final WebDriver driver) {
		log.info ("Clicking on Element...");
	}

	@Override
	public void beforeFindBy (final By by, final WebElement element, final WebDriver driver) {
		log.trace (format ("Finding element by [%s]", by));
	}

	@Override
	public <X> void beforeGetScreenshotAs (final OutputType <X> target) {
		log.info (format ("Capturing screenshot in format [%s]...", target));
	}

	@Override
	public void beforeGetText (final WebElement element, final WebDriver driver) {
		log.info ("Getting text from Element...");
	}

	@Override
	public void beforeNavigateBack (final WebDriver driver) {
		log.info ("Navigating back...");
	}

	@Override
	public void beforeNavigateForward (final WebDriver driver) {
		log.info ("Navigating forward...");
	}

	@Override
	public void beforeNavigateRefresh (final WebDriver driver) {
		log.info ("Refreshing the page...");
	}

	@Override
	public void beforeNavigateTo (final String url, final WebDriver driver) {
		log.info (format ("Navigating to [%s]...", url));
	}

	@Override
	public void beforeScript (final String script, final WebDriver driver) {
		final String message = "Executing script [%s]...";
		log.trace (format (message, script));
	}

	@Override
	public void beforeSwitchToWindow (final String windowName, final WebDriver driver) {
		log.info (format ("Switching to window [%s]...", windowName));
	}

	@Override
	public void onException (final Throwable throwable, final WebDriver driver) {
		final String message = "Error occurred: %s";
		log.error (format (message, throwable.getMessage ()));
		log.catching (throwable);
	}
}
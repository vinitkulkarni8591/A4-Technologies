package com.demo.qa.listeners;

import static com.demo.qa.config.Config.getConfig;
import static com.demo.qa.constants.ConfigKeys.TEST_RETRY_TIMES;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retryer implements IRetryAnalyzer {
	private static int maxTry = Integer.parseInt (getConfig (TEST_RETRY_TIMES, "1"));
	private int count = 0;

	@Override
	public boolean retry (final ITestResult result) {
		if (result.getStatus () == ITestResult.FAILURE) {
			final Throwable cause = result.getThrowable ();
			if (cause != null
				&& (cause instanceof NoSuchElementException || cause instanceof StaleElementReferenceException)) {
				if (this.count < maxTry) {
					this.count++;
					return true;
				}
			}
		}
		return false;
	}
}
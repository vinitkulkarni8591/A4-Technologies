package com.demo.qa.selenium;

import static com.demo.qa.config.Config.getConfig;
import static com.demo.qa.constants.ConfigKeys.BROWSER;
import static com.demo.qa.constants.ConfigKeys.IMPLICIT_DELAY;
import static com.demo.qa.constants.ConfigKeys.PAGE_TIMEOUT;
import static com.demo.qa.constants.ConfigKeys.SCREEN_HEIGHT;
import static com.demo.qa.constants.ConfigKeys.SCREEN_WIDTH;
import static com.demo.qa.constants.ConfigKeys.SCRIPT_TIMEOUT;
import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;
import static java.lang.System.getProperty;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.demo.qa.listeners.DriverListener;

public class Browser {
	private static final ThreadLocal<EventFiringWebDriver> driverThread = new ThreadLocal<>();
	private static final Logger log = LogManager.getLogger(Browser.class);
	private static WebDriver webdriver;

	private static void driver(final EventFiringWebDriver driver) {
		driverThread.set(driver);

	}

	private static WebDriver setupChromeDriver() {
		log.info("Setting up Chrome driver...");
		System.setProperty("webdriver.chrome.silentOutput", "true");
		System.setProperty("webdriver.chrome.driver",
				getProperty("user.dir") + "/src/test/resources/drivers/chromedriver.exe");
		webdriver = new ChromeDriver();
		return webdriver;
	}

	private static WebDriver setupFirefoxDriver() {
		log.info("Setting up Firefox driver...");
		System.setProperty("webdriver.gecko.driver",
				getProperty("user.dir") + "/src/test/resources/drivers/geckodriver.exe");
		webdriver = new FirefoxDriver();
		return webdriver;

	}

	public BrowserActions action() {
		log.trace("Preparing to perform action on browser...");
		return new BrowserActions(driver());
	}

	public void start(final String browserName) throws MalformedURLException {
		log.info("Starting driver...");
		String target = "CHROME";
		if (browserName != null) {
			target = browserName.toUpperCase();
		} else {
			target = getProperty(BROWSER, getConfig(BROWSER, target));
		}
		final AvailabeBrowser browser = AvailabeBrowser.valueOf(target.toUpperCase());
		final WebDriver driver = setupDriver(browser);
		final EventFiringWebDriver wd = new EventFiringWebDriver(driver);
		wd.register(new DriverListener());
		driver(wd);
		setupDriverOptions();
	}

	public void stop() {
		log.info("Stopping driver...");
		driver().unregister(new DriverListener()).quit();
		driver(null);
	}

	EventFiringWebDriver driver() {
		return Browser.driverThread.get();
	}

	private void manageOptions(final Consumer<Options> options) {
		options.accept(driver().manage());
	}

	private void manageTimeouts(final Consumer<Timeouts> timeouts) {
		timeouts.accept(driver().manage().timeouts());
	}

	private void manageWindow(final Consumer<Window> window) {
		window.accept(driver().manage().window());
	}

	private void setupDriverOptions() {
		manageTimeouts(t -> t.pageLoadTimeout(parseLong(getConfig(PAGE_TIMEOUT, "60")), TimeUnit.SECONDS));
		manageTimeouts(t -> t.setScriptTimeout(parseLong(getConfig(SCRIPT_TIMEOUT, "60")), TimeUnit.SECONDS));
		manageTimeouts(t -> t.implicitlyWait(parseLong(getConfig(IMPLICIT_DELAY, "1")), TimeUnit.SECONDS));
		manageOptions(Options::deleteAllCookies);
		manageWindow(w -> w.setSize(
				new Dimension(parseInt(getConfig(SCREEN_WIDTH, "1280")), parseInt(getConfig(SCREEN_HEIGHT, "768")))));
	}

	private static WebDriver setupDriver(final AvailabeBrowser browser) {
		switch (browser) {
		case CHROME:
			return setupChromeDriver();
		case FIREFOX:
			return setupFirefoxDriver();
		default:
			return setupFirefoxDriver();
		}
	}
	
	public WebDriver getWebDriver() {
		return webdriver;
	}

}
package com.demo.qa.listeners;

import static java.lang.String.format;
import static java.time.Duration.ofMillis;

import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class SuiteListener implements ISuiteListener {
	private static final String line = StringUtils.repeat ('=', 50);
	private static final Logger log = LogManager.getLogger (SuiteListener.class);
	private long end;
	private long start;

	@Override
	public void onFinish (final ISuite suite) {
		this.end = System.currentTimeMillis ();
		logTestSuite (log::info, suite, "Test Suite Execution finished for Suite [%s]...");
	}

	@Override
	public void onStart (final ISuite suite) {
		this.start = System.currentTimeMillis ();
		logTestSuite (log::info, suite, "Test Suite Execution started for Suite [%s]...");
	}

	private void logTestSuite (final Consumer <String> res, final ISuite suite, final String message) {
		log.info (line);
		res.accept (format (message, suite.getName ()));
		if (this.end > this.start) {
			final long total = this.end - this.start;
			log.info (format ("Time taken: %d secs", ofMillis (total).getSeconds ()));
		}
		log.info (line);
	}
}
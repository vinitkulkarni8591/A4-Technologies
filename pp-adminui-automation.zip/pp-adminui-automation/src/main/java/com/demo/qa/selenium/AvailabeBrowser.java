/**
 *
 */
package com.demo.qa.selenium;


public enum AvailabeBrowser {

	CHROME,
	FIREFOX,
	REMOTE;

}

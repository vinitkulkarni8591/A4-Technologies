package com.demo.qa.constants;

public interface ConfigKeys {
	String TEST_RETRY_TIMES = "ui.test.retry.times";
	String SCREENSHOT_ON_ERROR = "ui.screenshot.onerror";
	String BROWSER = "test.browser";
	String IMPLICIT_DELAY = "ui.timeout.default";
	String PAGE_TIMEOUT = "ui.timeout.page";
	String SCREEN_HEIGHT = "ui.screen.height";
	String SCREEN_WIDTH = "ui.screen.width";
	String SCRIPT_TIMEOUT = "ui.timeout.script";
	String EXPLICIT_DELAY = "ui.timeout.explicit";
	String PAUSE_TIME = "ui.timeout.driverpause";
	String HIGHLIGHT_DELAY = "ui.delay.highlight";
	String HOVER_DELAY = "ui.delay.hover";
	String UI_TESTDATA_FILEPATH = "ui.excel.path";

}

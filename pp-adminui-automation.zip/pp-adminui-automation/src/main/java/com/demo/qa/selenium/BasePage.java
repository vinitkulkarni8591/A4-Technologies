package com.demo.qa.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class BasePage {
	protected final Browser browser;

	public BasePage (final Browser browser) {
		this.browser = browser;
		PageFactory.initElements (this.browser.driver (), this);
	}

	public BrowserActions action () {
		return this.browser.action ();
	}

	public ElementAction action (final By locator) {
		return new ElementAction (action (), locator);
	}

	public ElementAction action (final WebElement element) {
		return new ElementAction (action (), element);
	}

	public Browser browser () {
		return this.browser;
	}
}
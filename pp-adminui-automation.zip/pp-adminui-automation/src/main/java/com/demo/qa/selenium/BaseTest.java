package com.demo.qa.selenium;

import static com.demo.qa.config.Config.getConfig;
import static com.demo.qa.constants.ConfigKeys.SCREENSHOT_ON_ERROR;

import java.net.MalformedURLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

public class BaseTest {
	protected static Browser browser;

	@Parameters ("test.browser")
	@BeforeTest (alwaysRun = true)
	public void setupTest (@Optional final String browserName) throws MalformedURLException {
		browser = new Browser ();
		browser.start (browserName);
	}

	@AfterMethod (alwaysRun = true)
	public void teardownMethod (final ITestResult result) {
		final boolean screenshotOnError = Boolean.parseBoolean (getConfig (SCREENSHOT_ON_ERROR, "false"));
		if (screenshotOnError && (result.getStatus () == ITestResult.FAILURE)) {
			if (!browser.action ()
				.isClosed ()) {
				browser.action ()
					.saveScreenshot ();
			}
		}
	}

	@AfterTest (alwaysRun = true)
	public void teardownTest () {
		browser.stop ();
		browser = null;
	}
}
package com.demo.qa.listeners;

import static java.lang.String.format;
import static java.time.Duration.ofMillis;

import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
	private static final String line = StringUtils.repeat ('=', 50);
	private static final Logger log = LogManager.getLogger (TestListener.class);

	private static void logTestContext (final Consumer <String> res, final ITestContext context, final String message) {
		log.info (line);
		res.accept (format (message, context.getName ()));
		if (context.getEndDate () != null) {
			log.info (format ("Test executed on [%s]...", context.getEndDate ()));
		}
		log.info (line);
	}

	private static void logTestResult (final Consumer <String> res, final ITestResult result, final String message) {
		log.info (line);
		res.accept (format (message, result.getName ()));
		if (result.getStatus () != ITestResult.STARTED) {
			final long start = result.getStartMillis ();
			final long end = result.getEndMillis ();
			final long total = end - start;
			log.info (format ("Time taken: %d secs", ofMillis (total).getSeconds ()));
		}
		log.info (line);
	}

	private static void logTestResult (final Consumer <String> res, final ITestResult result, final Throwable cause) {
		if (cause != null) {
			logTestResult (res, result, cause.getMessage ());
		}
		else {
			logTestResult (res, result, "Unknown Exception!!");
		}
	}

	@Override
	public void onFinish (final ITestContext context) {
		logTestContext (log::info, context, "Test Execution finished for Test [%s]...");
		
	}

	@Override
	public void onStart (final ITestContext context) {
		logTestContext (log::info, context, "Test Execution started for Test [%s]...");
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage (final ITestResult result) {
		logTestResult (log::warn, result, "[--] - [%s] PARTIAL FAILED...");
	}

	@Override
	public void onTestFailure (final ITestResult result) {
		logTestResult (log::fatal, result, "[-] - [%s] FAILED...");
		logTestResult (log::fatal, result, result.getThrowable ());
	}

	@Override
	public void onTestSkipped (final ITestResult result) {
		logTestResult (log::error, result, "[*] - [%s] SKIPPED...");
	}

	@Override
	public void onTestStart (final ITestResult result) {
		logTestResult (log::info, result, "Test Execution started for method [%s]...");
	}

	@Override
	public void onTestSuccess (final ITestResult result) {
		logTestResult (log::info, result, "[+] - [%s] PASSED...");
	}
}
package com.demo.actions;

import com.demo.pages.CheckoutInfoPage;
import com.demo.qa.selenium.Browser;

public class CheckoutInfoActions extends DefaultAction {

	private CheckoutInfoPage checkoutInfoPage;

	public CheckoutInfoActions(Browser browser) {
		super(browser);
		this.checkoutInfoPage = new CheckoutInfoPage(browser);
	}

	public void enterCheckoutDetails() {
		this.checkoutInfoPage.firstName().enterText("Vinit");
		this.checkoutInfoPage.lastName().enterText("Kulkarni");
		this.checkoutInfoPage.postalCode().enterText("422011");
		this.checkoutInfoPage.continueButton().isEnabled();
		this.checkoutInfoPage.continueButton().click();
	}
}

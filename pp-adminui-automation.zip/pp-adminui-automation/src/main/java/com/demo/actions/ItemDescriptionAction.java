package com.demo.actions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import com.demo.pages.ItemdescriptionPage;
import com.demo.qa.selenium.Browser;

public class ItemDescriptionAction extends DefaultAction {
	private ItemdescriptionPage itemdescriptionPage;

	public ItemDescriptionAction(Browser browser) {
		super(browser);
		this.itemdescriptionPage = new ItemdescriptionPage(browser);
	}

	public void productAddToCart(String productName, String productDescription, String productPrice) {
		int initalCartCount = 0;
		assertEquals(productName, this.itemdescriptionPage.itemName().text());

		assertEquals(productDescription, this.itemdescriptionPage.itemDescription().text().replace(",", ""));
		assertTrue(this.itemdescriptionPage.itemPrice().text().contains(productPrice));
		try {
			initalCartCount = Integer.parseInt(this.itemdescriptionPage.itemCountInCart().text());
		} catch (Exception e) {
			initalCartCount = 0;
		}
		this.itemdescriptionPage.itemAddToCart().isEnabled();
		this.itemdescriptionPage.itemAddToCart().click();
		int newCartCount = Integer.parseInt(this.itemdescriptionPage.itemCountInCart().text());

		if (initalCartCount + 1 == newCartCount) {
			System.out.println("Item added to cart successfully");
		}
	}

	public void productRemoveToCart() {
		int initalCartCount = 0;
		int newCartCount = 0;

		initalCartCount = Integer.parseInt(this.itemdescriptionPage.itemCountInCart().text());

		this.itemdescriptionPage.productremovefromcart().isEnabled();
		this.itemdescriptionPage.productremovefromcart().click();
		try {
			newCartCount = Integer.parseInt(this.itemdescriptionPage.itemCountInCart().text());
		} catch (Exception e) {
			newCartCount = 0;
		}
		if (initalCartCount - 1 == newCartCount) {
			System.out.println("Item removed to cart successfully");
		}

	}

	public void navigateToCart() {
		this.itemdescriptionPage.cart().click();

	}

}

package com.demo.actions;

import static org.testng.Assert.assertEquals;

import com.demo.pages.OrderConfirmationPage;
import com.demo.qa.selenium.Browser;

public class OrderConfirmationAction extends DefaultAction {

	private OrderConfirmationPage orderConfirmationPage;

	public OrderConfirmationAction(Browser browser) {
		super(browser);
		this.orderConfirmationPage = new OrderConfirmationPage(browser);
	}

	public void verifyOrderCOnfirmation() {
		assertEquals(this.orderConfirmationPage.orderConfirmation().text(), "Thank you for your order!");
		assertEquals(this.orderConfirmationPage.OrderSubMessage().text(),
				"Your order has been dispatched, and will arrive just as fast as the pony can get there!");
	}

}

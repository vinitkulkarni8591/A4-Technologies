package com.demo.actions;

import static org.testng.Assert.assertEquals;

import com.demo.pages.CheckoutConfirmPage;
import com.demo.qa.selenium.Browser;

public class CheckoutConfirmAction extends DefaultAction {

	private CheckoutConfirmPage checkoutConfirmPage;

	public CheckoutConfirmAction(Browser browser) {
		super(browser);
		this.checkoutConfirmPage = new CheckoutConfirmPage(browser);
	}

	public void confirmCartItem(String productName, String productDescription, String productPrice) {
		assertEquals(productName, this.checkoutConfirmPage.cartItemName().text());
		assertEquals(productDescription, this.checkoutConfirmPage.cartItemDescription().text().replace(",", ""));
		assertEquals(productPrice, this.checkoutConfirmPage.cartItemPrice().text());
		this.checkoutConfirmPage.finishbutton().isEnabled();
		this.checkoutConfirmPage.finishbutton().click();
	}

}

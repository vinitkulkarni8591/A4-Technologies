package com.demo.actions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import com.demo.pages.CartPage;
import com.demo.qa.selenium.Browser;

public class CartActions extends DefaultAction {

	private CartPage cartPage;

	public CartActions(Browser browser) {
		super(browser);
		this.cartPage = new CartPage(browser);
	}

	public void verifyCartItem(String itemName, String description, String price) {
		assertEquals(itemName, this.cartPage.cartItemName().text());
		assertEquals(description, this.cartPage.cartDescription().text().replace(",", ""));
		assertTrue(this.cartPage.cartPrice().text().contains(price));

		this.cartPage.checkoutButton().isEnabled();
		this.cartPage.checkoutButton().click();

	}
}

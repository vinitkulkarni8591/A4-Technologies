package com.demo.actions;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Set;

import org.openqa.selenium.By;

import com.demo.pages.HomePage;
import com.demo.qa.selenium.Browser;

public class HomePageActions extends DefaultAction {
	private HomePage homepage;

	public HomePageActions(Browser browser) {
		super(browser);
		this.homepage = new HomePage(browser);
	}

	public void selectItemfromHomePage(String itemName) {
		this.homepage.hamburgerMenu().find(By.xpath("//div[text()='Sauce Labs Backpack']")).click();

	}

	public void verifyBottomLinks() throws AWTException {
		this.homepage.twitterButton().click();
		String currentHandle = browser.getWebDriver().getWindowHandle();
		Set<String> handles = browser.getWebDriver().getWindowHandles();
		for (String actual : handles) {
			if (!actual.equalsIgnoreCase(currentHandle)) {
				browser.getWebDriver().switchTo().window(actual);
			}
		}
		assertEquals(this.homepage.twitterheader().text(), "Sauce Labs");
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_W);
		robot.keyRelease(KeyEvent.VK_W);
		robot.keyRelease(KeyEvent.VK_CONTROL);


	}

}


package com.demo.actions;

import static org.testng.Assert.assertEquals;

import com.demo.pages.HomePage;
import com.demo.pages.LoginPage;
import com.demo.qa.selenium.Browser;

import io.qameta.allure.Step;

public class LoginPageActions extends DefaultAction {

	private final LoginPage loginPage;
	private final HomePage homePage;

	public LoginPageActions(final Browser browser) {
		super(browser);
		this.loginPage = new LoginPage(browser);
		this.homePage = new HomePage(browser);
	}

	public void loginInAdminUi(String userName, String password, boolean isValid) {
		this.loginPage.userName().clear();
		this.loginPage.userName().enterText(userName);
		this.loginPage.password().clear();
		this.loginPage.password().enterText(password);
		this.loginPage.loginButton().waitUntilClickable();
		this.loginPage.loginButton().click();
		this.browser.action().pause();
		if (isValid) {
			verifyValidLogin();
		} else {
			verifyInvalidLogin();
		}
	}

	@Step("Verify invalid login error message.")
	public void verifyInvalidLogin() {
		String uiText = this.loginPage.errorMessage().text();
		assertEquals(uiText, "Epic sadface: Username and password do not match any user in this service");
	}

	@Step("Verify valid login.")
	public void verifyValidLogin() {
		this.homePage.hamburgerMenu().click();
		this.homePage.logoutLink().text().equals("Logout");
	}
}

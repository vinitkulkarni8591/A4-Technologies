package com.demo.actions;

import com.demo.qa.selenium.Browser;

public class DefaultAction {
	protected Browser browser;

	public DefaultAction (final Browser browser) {
		this.browser = browser;
	}

	public void navigate (final String url) {
		this.browser.action ()
			.navigateTo (url);
	}
}

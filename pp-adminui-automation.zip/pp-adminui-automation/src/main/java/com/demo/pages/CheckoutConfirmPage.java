package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class CheckoutConfirmPage extends BasePage {

	public CheckoutConfirmPage(Browser browser) {
		super(browser);
	}

	public ElementAction finishbutton() {
		return action(By.id("finish"));
	}

	public ElementAction cartItemName() {
		return action(By.cssSelector(".inventory_item_name"));
	}

	public ElementAction cartItemDescription() {
		return action(By.cssSelector(".inventory_item_desc"));
	}

	public ElementAction cartItemPrice() {
		return action(By.cssSelector(".inventory_item_price"));
	}
}

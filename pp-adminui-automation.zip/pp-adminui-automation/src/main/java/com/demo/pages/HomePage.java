package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class HomePage extends BasePage {
	public HomePage(Browser browser) {
		super(browser);
	}

	public ElementAction hamburgerMenu() {
		return action(By.id("react-burger-menu-btn"));
	}

	public ElementAction logoutLink() {
		return action(By.id("logout_sidebar_link"));
	}

	public ElementAction twitterButton() {
		return action(By.cssSelector(".social_twitter > a"));
	}

	public ElementAction twitterheader() {
		return action(By.xpath("(((//span[text()='Follow'])[1]/../../../../../../../../div)[2]/div/div/div)[1]"));
	}

	public ElementAction facebookLink() {
		return action(By.cssSelector(".social_facebook > a"));
	}

	public ElementAction facebookHeader() {
		return action(By.cssSelector(".xg8j3zb"));
	}

	public ElementAction linkedInLisk() {
		return action(By.cssSelector(".social_linkedin > a"));
	}
	
	public ElementAction linkedInHeader() {
		return action(By.cssSelector(".authwall-join-form__title"));
	}
}
package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class OrderConfirmationPage extends BasePage {

	public OrderConfirmationPage(Browser browser) {
		super(browser);
	}

	public ElementAction orderConfirmation() {
		return action(By.cssSelector(".complete-header"));
	}

	public ElementAction OrderSubMessage() {
		return action(By.cssSelector(".complete-text"));
	}
}

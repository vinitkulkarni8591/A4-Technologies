package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class CheckoutInfoPage extends BasePage {

	public CheckoutInfoPage(Browser browser) {
		super(browser);
		// TODO Auto-generated constructor stub
	}

	public ElementAction firstName() {
		return action(By.id("first-name"));

	}

	public ElementAction lastName() {
		return action(By.id("last-name"));
	}
	
	public ElementAction postalCode() {
		return action(By.id("postal-code"));
		
	}
	
	public ElementAction continueButton() {
		return action(By.id("continue"));
	}

}

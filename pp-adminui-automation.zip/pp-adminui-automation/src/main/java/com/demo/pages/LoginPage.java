package com.demo.pages;

import org.openqa.selenium.By;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class LoginPage extends com.demo.qa.selenium.BasePage {
	public LoginPage(Browser browser) {
		super(browser);
	}

	public ElementAction userName() {
		return action(By.id("user-name"));
	}

	public ElementAction password() {
		return action(By.id("password"));
	}

	public ElementAction loginButton() {
		return action(By.id("login-button"));
	}

	public ElementAction errorMessage() {
		return action(By.cssSelector(".error-message-container > h3"));
	}

}

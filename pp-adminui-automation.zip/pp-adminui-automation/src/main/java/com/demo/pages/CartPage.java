package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class CartPage extends BasePage {

	public CartPage(Browser browser) {
		super(browser);
	}

	public ElementAction cartItemName() {
		return action(By.cssSelector(".inventory_item_name"));
	}

	public ElementAction cartDescription() {
		return action(By.cssSelector(".inventory_item_desc"));
	}

	public ElementAction cartPrice() {
		return action(By.cssSelector(".inventory_item_price"));
	}

	public ElementAction checkoutButton() {
		return action(By.id("checkout"));
	}
}

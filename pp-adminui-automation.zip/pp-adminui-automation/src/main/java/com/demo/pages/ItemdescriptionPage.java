package com.demo.pages;

import org.openqa.selenium.By;

import com.demo.qa.selenium.BasePage;
import com.demo.qa.selenium.Browser;
import com.demo.qa.selenium.ElementAction;

public class ItemdescriptionPage extends BasePage {

	public ItemdescriptionPage(Browser browser) {
		super(browser);
		// TODO Auto-generated constructor stub
	}

	public ElementAction itemName() {
		return action(By.cssSelector(".inventory_details_name"));
	}

	public ElementAction itemDescription() {
		return action(By.cssSelector(".inventory_details_desc"));
	}

	public ElementAction itemPrice() {
		return action(By.cssSelector(".inventory_details_price"));
	}

	public ElementAction itemAddToCart() {
		return action(By.cssSelector("#add-to-cart-sauce-labs-backpack"));
	}

	public ElementAction itemCountInCart() {
		return action(By.cssSelector(".shopping_cart_badge"));
	}

	public ElementAction productremovefromcart() {
		return action(By.cssSelector("#remove-sauce-labs-backpack"));
	}

	public ElementAction cart() {
		return action(By.cssSelector(".shopping_cart_link"));
	}
}

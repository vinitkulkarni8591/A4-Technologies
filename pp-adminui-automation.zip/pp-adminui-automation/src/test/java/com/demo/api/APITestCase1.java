package com.demo.api;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.demo.qa.constants.TestGroups;

import io.restassured.response.Response;

public class APITestCase1 {
	@Test(groups = TestGroups.REGRESSION)
	public void getUsersList() {

		Response response = given().when().get("https://reqres.in/api/users?page=2");
		response.then().log().all();
		System.out.println(response.getStatusCode());
		assertEquals(response.getStatusCode(), 200);
		JSONObject object = new JSONObject(response.asString());
		JSONArray array = object.getJSONArray("data");
		System.out.println(array.length());
		for (int i = 0; i < array.length(); i++) {
			JSONObject obj = array.getJSONObject(i);
			System.out.println(i + " Obj -> id : " + obj.getInt("id"));
			System.out.println(i + " Obj -> email : " + obj.getString("email"));
			System.out.println(i + " Obj -> FirstName : " + obj.getString("first_name"));
			System.out.println(i + " Obj -> lastName : " + obj.getString("last_name"));
			System.out.println();
		}
	}

	@Test(groups = TestGroups.REGRESSION)
	public void getSingleUser() {
		Response response = given().when().get("https://reqres.in/api/users/2");
		response.then().log().all();
		System.out.println(response.getStatusCode());
		assertEquals(response.getStatusCode(), 200);

		JSONObject object = new JSONObject(response.asString());
		JSONObject obj = object.getJSONObject("data");
		System.out.println(" Obj -> id : " + obj.getInt("id"));
		System.out.println(" Obj -> email : " + obj.getString("email"));
		System.out.println(" Obj -> FirstName : " + obj.getString("first_name"));
		System.out.println(" Obj -> lastName : " + obj.getString("last_name"));
	}

	@Test(groups = TestGroups.REGRESSION)
	public void postCreateUsers() {
		String body = "{\r\n" + "    \"name\": \"Vinit\",\r\n" + "    \"job\": \"Automation\"\r\n" + "}";
		Response response = given().when().body(body).post("https://reqres.in/api/users");

		response.then().log().all();
		System.out.println(response.getStatusCode());
		assertEquals(response.getStatusCode(), 201);

	}

	@DataProvider(name = "patchUserDetails")
	private Iterator<List> patchUserDetails() {
		List<List> testData = new ArrayList<>();
		List<String> data = new ArrayList<String>();
		data.add("Vinit S");
		data.add("Selenium Automation");
		testData.add(data);
		return testData.iterator();
	}

	@Test(dataProvider = "patchUserDetails", groups = TestGroups.REGRESSION)
	public void patchUserDetails(List testData) {
		String body = "{\r\n" + "    \"name\": \"" + testData.get(0) + "\",\r\n" + "    \"job\": \"" + testData.get(1)
				+ "\"\r\n" + "}";
		Response response = given().when().body(body).patch("https://reqres.in/api/users/2");

		response.then().log().all();
		System.out.println(response.getStatusCode());
		assertEquals(response.getStatusCode(), 200);
	}

	@DataProvider(name = "updateUserData")
	private Iterator<String> updateUserData() {
		List<String> userName = new ArrayList<String>();
		userName.add("Vinit Sanjay");
		return userName.iterator();
	}

	@Test(dataProvider = "updateUserData", groups = TestGroups.REGRESSION)
	public void putUpdateUser(String name) {
		String body = "{\r\n" + "    \"name\": \"" + name + "\",\r\n" + "    \"job\": \"Automation\"\r\n" + "}";
		Response response = given().when().body(body).put("https://reqres.in/api/users/2");

		response.then().log().all();
		System.out.println(response.getStatusCode());
		assertEquals(response.getStatusCode(), 200);
		System.out.println("Updated Time : " + new JSONObject(response.asString()).getString("updatedAt"));

	}

}

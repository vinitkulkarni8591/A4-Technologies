package com.demo.UI;

import static com.demo.qa.config.Config.getAppConfig;
import static com.demo.qa.constants.ConfigKeys.UI_TESTDATA_FILEPATH;
import static java.lang.System.getProperty;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.junit.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.demo.actions.LoginPageActions;
import com.demo.qa.constants.TestGroups;
import com.demo.qa.selenium.BaseTest;
import com.demo.qa.utils.ExcelUtil;;

public class LoginTest extends BaseTest {
	private LoginPageActions loginPageActions;
	private final String UITESTDATAFILEPATH = getAppConfig(UI_TESTDATA_FILEPATH);
	String[] testData = null;

	private void getTestData(String data) {
		this.testData = data.replace("[", "").replace("]", "").split(",");
	}

	@BeforeClass
	public void setupTest() {
		
	}

	@DataProvider(name = "loginCredentials")
	public Iterator<Object[]> loginCredentials() throws IOException {
		List<Object[]> data = null;
		data = ExcelUtil.getTestData(getProperty("user.dir") + UITESTDATAFILEPATH, "LoginData", "ValidData", 2);

		return data.iterator();
	}

	@Test(dataProvider = "loginCredentials", groups = TestGroups.SMOKE)
	public void loginCredentials(String data) {
		getTestData(data);
		this.loginPageActions = new LoginPageActions(browser);
		this.loginPageActions.navigate("https://www.saucedemo.com/");
		this.loginPageActions.loginInAdminUi(testData[0].trim(), testData[1].trim(),
				Boolean.parseBoolean(testData[2].trim()));
	}

}

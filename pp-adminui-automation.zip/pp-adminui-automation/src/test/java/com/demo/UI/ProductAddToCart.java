package com.demo.UI;

import static com.demo.qa.config.Config.getAppConfig;
import static com.demo.qa.constants.ConfigKeys.UI_TESTDATA_FILEPATH;
import static java.lang.System.getProperty;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.demo.actions.HomePageActions;
import com.demo.actions.ItemDescriptionAction;
import com.demo.actions.LoginPageActions;
import com.demo.qa.constants.TestGroups;
import com.demo.qa.selenium.BaseTest;
import com.demo.qa.utils.ExcelUtil;

public class ProductAddToCart extends BaseTest {
	private final String UITESTDATAFILEPATH = getAppConfig(UI_TESTDATA_FILEPATH);
	String[] testData = null;
	private HomePageActions homePageActions;
	private LoginPageActions loginPageActions;
	private ItemDescriptionAction itemDescriptionActions;

	private void getTestData(String data) {
		this.testData = data.replace("[", "").replace("]", "").split(",");
	}

	@DataProvider(name = "itenAddToCartFromDescription")
	public Iterator<Object[]> itenAddToCartFromDescription() throws IOException {
		List<Object[]> data = ExcelUtil.getTestData(getProperty("user.dir") + UITESTDATAFILEPATH, "LoginData",
				"itenAddToCartFromDescription", 1);
		return data.iterator();
	}

	@Test(groups = TestGroups.SMOKE, dataProvider = "itenAddToCartFromDescription")
	public void itenAddToCartFromDescription(String data) throws InterruptedException {

		getTestData(data);
		this.loginPageActions = new LoginPageActions(browser);
		this.loginPageActions.navigate("https://www.saucedemo.com/");
		this.loginPageActions.loginInAdminUi(testData[0].trim(), testData[1].trim(),
				Boolean.parseBoolean(testData[2].trim()));

		browser.action().refresh();
		this.homePageActions = new HomePageActions(browser);
		this.homePageActions.selectItemfromHomePage(testData[3].trim());
		
		this.itemDescriptionActions = new ItemDescriptionAction(browser);
		this.itemDescriptionActions.productAddToCart(testData[3].trim(),testData[4].trim(),testData[5].trim());
;
	}
}
